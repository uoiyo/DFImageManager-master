// The MIT License (MIT)
//
// Copyright (c) 2015 Alexander Grebenyuk (github.com/kean).

#import <UIKit/UIKit.h>
#import "DFImageDecoding.h"

@interface DFAnimatedImageDecoder : NSObject <DFImageDecoding>

@end
