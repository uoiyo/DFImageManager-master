// The MIT License (MIT)
//
// Copyright (c) 2015 Alexander Grebenyuk (github.com/kean).

#import <UIKit/UIKit.h>

//! Project version number for DFImageManager.
FOUNDATION_EXPORT double DFImageManagerVersionNumber;

//! Project version string for DFImageManager.
FOUNDATION_EXPORT const unsigned char DFImageManagerVersionString[];

#import "DFImageManagerKit.h"
#import "DFImageManagerKit+UI.h"