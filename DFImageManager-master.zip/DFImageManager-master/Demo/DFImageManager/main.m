//
//  main.m
//  DFImageManager
//
//  Created by Alexander Grebenyuk on 10/09/15.
//  Copyright © 2015 Alexander Grebenyuk. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SDFAppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SDFAppDelegate class]));
    }
}
