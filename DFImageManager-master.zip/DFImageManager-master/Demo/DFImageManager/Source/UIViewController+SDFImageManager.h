//
//  UIViewController+SDFImageManager.h
//  DFImageManagerSample
//
//  Created by Alexander Grebenyuk on 1/5/15.
//  Copyright (c) 2015 Alexander Grebenyuk. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (SDFImageManager)

- (UIActivityIndicatorView *)df_showActivityIndicatorView;

@end
