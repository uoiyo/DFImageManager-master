//
//  AppDelegate.m
//  DFImageManagerSample
//
//  Created by Alexander Grebenyuk on 12/22/14.
//  Copyright (c) 2014 Alexander Grebenyuk. All rights reserved.
//

#import "SDFAppDelegate.h"

@interface SDFAppDelegate ()

@end

@implementation SDFAppDelegate

@end
