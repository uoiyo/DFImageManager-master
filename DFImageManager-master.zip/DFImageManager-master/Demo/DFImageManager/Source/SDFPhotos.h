//
//  SFDPhotos.h
//  DFImageManager
//
//  Created by Alexander Grebenyuk on 10/09/15.
//  Copyright © 2015 Alexander Grebenyuk. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SDFPhotos : NSObject

+ (NSArray /* NSURL */ *)URLsForSmallPhotos;

@end
